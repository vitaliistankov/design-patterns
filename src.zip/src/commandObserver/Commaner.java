package commandObserver;

public interface Commaner {
    public void executeWorkout(Workout workout);
}
