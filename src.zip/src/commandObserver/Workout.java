package commandObserver;

@FunctionalInterface
public interface Workout {
    void execute();
}
