package commandObserver;

public class Couch {
    public void executeWorkout(Workout workout){
        workout.execute();
    }
}
