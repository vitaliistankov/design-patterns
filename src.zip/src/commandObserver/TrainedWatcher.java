package commandObserver;

public class TrainedWatcher extends Trained {
    TrainedWatcher(String name) {
        super(name);
    }
}
